
var Ronaldo = {Genre: "Sport" , Afkomst: "Portugees" , Hobby:"Voetballen" };

var Dicaprio = {Genre: "Acteur" , Afkomst: "Amerikaans" , Hobby: "Acteren" };

var Pewdiepie = {Genre: "Entertainer" , Afkomst: "Zweeds" , Hobby: "filmpjes maken" };

var lijstartiesten = [Ronaldo, Dicaprio, Pewdiepie];

for (let artiesten of lijstartiesten) {
    console.log(artiesten);
}

